from django.db import models

class Movie(models.Model):
    movie_title = models.CharField(max_length=50, null=False)
    movie_gender = models.CharField(max_length=20, null=False)
    directors_name = models.CharField(max_length=30, null=False)
    publication_date = models.DateField(null=False)
    sinopsis = models.TextField()
    
    def __str__(self):
        return f"{self.movie_title} {self.movie_gender}"